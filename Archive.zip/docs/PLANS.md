# BlockBard — Engineering Plans & Feature Roadmap

This document outlines the architectural plans, technical designs, and feature roadmap for the BlockBard Minecraft Fabric mod.

---

## 1. Recently Implemented Enhancements

### 1.1 Virtual Keyboard Instrument Coverage
- **Status**: Completed
- **Details**:
  - Dynamically populates `playableInstruments` via `NoteBlockInstrument.entries.filter { it.isTunable }`.
  - Expands the previous 16-instrument limit to all 20 vanilla instruments, including copper Trumpet variants (`TRUMPET`, `TRUMPET_EXPOSED`, `TRUMPET_WEATHERED`, `TRUMPET_OXIDIZED`).
  - Added clean button formatting (`formatInstrumentName()`) so long names like `TRUMPET_EXPOSED` display cleanly as `Trp (Exposed)`.
  - Both mouse clicks on `VirtualKeyboardWidget` and hardware keyboard triggers (1–9, A–Z, Q–R) dispatch notes using the selected trumpet instrument.

### 1.2 Untunable Block Handling & In-World Highlighting
- **Status**: Completed
- **Details**:
  - Blocks that fail tuning after 3 retry attempts are evaluated with `PlayerController.diagnoseBlockInteractability()`.
  - Occluded blocks (obstructed line of sight) are marked as untunable from the current standing spot in `NoteBlockRegistry`.
  - Untunable blocks remain in `allPlayable()` so attack playback (`PlayerController.playNoteAt()`) can still strike them.
  - `MidiToOrganMapper` prioritizes tunable blocks over untunable blocks when assigning notes that require retuning clicks, while still using untunable blocks for exact 0-click matches or fallbacks.
  - Implemented `ManualTuningHighlighter` using Fabric's `LevelRenderEvents.BEFORE_GIZMOS`. Draws 3D red/amber bounding boxes (`CuboidGizmo`) with `alwaysOnTop = true` and billboard text (`TextGizmo`) over untunable blocks showing target note, required clicks, and failure reason.
  - Highlights update dynamically every client tick and automatically clear once the player manually tunes a block in the world.
  - Added `/bb highlights` and `/bb clearhighlights` client commands.

### 1.3 Fine-Grained Failstate Diagnostics
- **Status**: Completed
- **Details**:
  - Added `TuningFailState` enum with distinct failure categories:
    - `OCCLUDED`: Target block is blocked by intervening blocks; cannot right-click through walls.
    - `OUT_OF_REACH`: Distance exceeds 4.5 blocks from eye position.
    - `UNRESPONSIVE`: Clicks were dispatched, but block state never changed (anti-cheat dropped packet or region claim protection).
    - `INTERACT_REJECTED`: Interaction blocked by non-survival gamemode or full hotbar.
    - `BLOCK_MISSING`: Block was destroyed or removed from world.
    - `DESYNC`: Note changed across retries but failed to reach target index.
  - Logs categorized tags across SLF4J, `BlockBardLogBuffer`, and in-game chat.

### 1.3a Log Hygiene and Clipboard Crash Fix
- **Status**: Completed (pass 1 of `blockbard-tuning-reliability-plan.md`)
- **Details**:
  - Logs tab "Copy All" crashed with `OutOfMemoryError: Out of stack space` (LWJGL stack, not heap) when the copied text exceeded the thread stack. It now copies `BlockBardLogBuffer.getTailText(32_000)` inside a `try/catch`, and writes the full buffer to `<gameDir>/logs/blockbard-copy.txt` (path shown in chat).
  - `PlayerController.centerOnOrgan` logs the reach summary only when it changes, and lists at most 3 unreachable blocks plus "and N more".
  - `OrganScanner` writes scan, overflow and range log lines only when the scan result changed; the HARP overflow notice is INFO, not WARN. Chat feedback is unchanged.
  - `BlockBardLogBuffer.debug` stores entries only while `DebugLog.enabled` (the `debugLogging` setting).

### 1.3b MIDI Keyboard Connection
- **Status**: Implemented, untested on hardware (Yamaha SC3 over macOS Bluetooth)
- **Details**:
  - Previously `midiDeviceName` could only be set by hand-editing `config.json`; nothing in the mod called `connect`, so a keyboard was never opened and nothing was logged.
  - `/bb midi list|status|connect <name>|disconnect`. `connect` saves the device name; matching is exact, then case-insensitive, then unique substring (`MidiDeviceMatcher`). Fix: CoreMIDI lists one keyboard as an input and an output port with the same name; `connect` now opens the entry with `maxTransmitters != 0` (`selectSender`).
  - Live MIDI notes use `LiveNoteResolver`: harp preferred, else any pitched instrument already tuned to the exact pitch (guitar low, flute high on a 25/25/25 organ), else octave shifts per the existing Shift Mode and Max Octave Shift settings (2 covers all 88 keys, 1 covers 73, none covers 49). Live notes bypass the song assignment maps.
  - Startup logs the visible input devices; a saved device is retried every 10 s so a late Bluetooth connection works.
  - `/bb midi status` shows message and note-on counters, to separate "no messages arrive" from "messages arrive but no block plays".

### 1.4 In-World Organ Hologram Overlay
- **Status**: Completed (Referenced Litematica / MaLiLib overlay concepts)
- **Details**:
  - Implemented `OrganOverlayRenderer` using Fabric's `LevelRenderEvents.BEFORE_GIZMOS`.
  - Color-codes every scanned noteblock in the organ in real-time:
    - **Green**: Assigned and confirmed in tune.
    - **Amber / Yellow**: Assigned, requires tuning clicks ($+N$ clicks).
    - **Red**: Untunable / occluded from the standing spot.
    - **Cyan / Blue**: Available spare block.
    - **Orange**: Silenced (obstructed above).
    - **Magenta**: Mob head ambient block.
  - In-world toggle via <kbd>O</kbd> keybinding, `/bb overlay` command, and `[Holo: ON/OFF]` button in `MainScreen` Organ tab.

### 1.5 Organ Blueprint & Spherical Stage Builder Guide
- **Status**: Completed (Referenced SongPlayer's `Stage.java` spherical layout)
- **Details**:
  - Implemented `OrganBlueprintBuilder` calculating optimal 3D spherical noteblock positions across $y$-layers $-4$ to $+6$ within player reach.
  - Projects ghost bounding boxes and floating billboard labels with foundation material placement hints (`blockBelowHint`, e.g. "Copper (Trumpet)", "Gold (Bell)", "Packed Ice (Chime)") for unbuilt blocks.
  - Toggleable via `/bb blueprint [toggle|clear]` and `[Stage: ON/OFF]` button in `MainScreen`.

---

## 2. Drum Machine, Beat Maker & Synthesizer Workstation Pad

### 2.1 Architectural References
The workstation design synthesizes two open-source digital audio architectures:
1. **[Hydrogen Drum Machine](https://github.com/hydrogen-music/hydrogen)**:
   - Pattern-based 16-step sequencer (tracks $\times$ subdivisions).
   - Pattern matrix for chaining intro, verse, chorus, and fill patterns.
   - Dynamic BPM and swing humanization.
2. **[Giada Loop Machine](https://github.com/monocasual/giada)**:
   - 4x4 (16-pad) performance matrix for live finger drumming.
   - Quantized live overdubbing: player taps pads live, notes snap to the nearest 16th-note step on the grid.

### 2.2 In-Game Layout & Concept
```
┌────────────────────────────────────────────────────────────────────────┐
│                        BLOCKBARD BEAT STATION                          │
├────────────────────────────────────────────────────────────────────────┤
│ [▶ Play] [❚❚ Pause] [● Rec] [Tempo: 120 BPM] [Swing: 15%] [Export .mid]│
├──────────────────────────────────────┬─────────────────────────────────┤
│ 16-STEP SEQUENCER (Hydrogen style)   │ 4x4 PERFORMANCE PADS (MPC style)│
│                                      │                                 │
│ Track       1 2 3 4 5 6 7 8 9... 16  │  ┌───┬───┬───┬───┐              │
│ 1. Kick    [■· · · ■· · · ■· · · ■· ·]│  │ 1 │ 2 │ 3 │ 4 │  (Q W E R)   │
│ 2. Snare   [· · · · ■· · · · · · · ■·]│  ├───┼───┼───┼───┤              │
│ 3. Hat Cl  [■· ■· ■· ■· ■· ■· ■· ■· ·]│  │ 5 │ 6 │ 7 │ 8 │  (A S D F)   │
│ 4. Hat Op  [· · · · · · · ■· · · · · ·]│  ├───┼───┼───┼───┤              │
│ 5. Bass    [■· · · · · ■· · · ■· · · ·]│  │ 9 │10 │11 │12 │  (Z X C V)   │
│ 6. BitSynth[· · ■· · · · ■· · · ■· · ·]│  ├───┼───┼───┼───┤              │
│ 7. Pling   [· · · · ■· · · · · · · ■·]│  │13 │14 │15 │16 │  (1 2 3 4)   │
│ 8. MobSkel [· · · · · · · · · · · ■· ·]│  └───┴───┴───┴───┘              │
├──────────────────────────────────────┴─────────────────────────────────┤
│ Playhead:  ═══▶ (Step 5/16)                                            │
│ Pattern:   [A: Main Beat] [B: Fill] [C: Chorus]   [+ New Pattern]      │
└────────────────────────────────└───────────────────────────────────────┘
```

### 2.3 Technical Component Design
- **Package**: `kyrielie.blockbard.workstation`
- **Data Models**:
  ```kotlin
  data class StepNote(
      val active: Boolean = false,
      val noteIndex: Int = 0,
      val velocity: Float = 1.0f
  )

  data class TrackPattern(
      val instrument: NoteBlockInstrument,
      val defaultPitch: Int,
      val steps: Array<StepNote> = Array(16) { StepNote() }
  )

  data class BeatPattern(
      val name: String,
      val lengthSteps: Int = 16,
      val tracks: MutableList<TrackPattern> = mutableListOf()
  )
  ```
- **Sequencer Clock (`BeatClockEngine`)**:
  - Advances playhead using high-resolution timer synchronized to BPM.
  - Step interval: $\text{Interval (ms)} = \frac{60000}{\text{BPM} \times 4}$.
  - Dispatches notes directly to `ArpeggioScheduler.enqueue(NoteRequest(midiNote, instrument))`.
- **Minecraft Sound Mapping**:
  - Kick: `BASEDRUM` (Stone / Concrete)
  - Snare: `SNARE` (Sand / Gravel)
  - Hi-Hat: `HAT` (Glass / Sea Lantern)
  - Cowbell: `COW_BELL` (Soul Sand)
  - Bassline: `BASS` (Wood)
  - Synth Lead: `BIT` (Emerald) or `TRUMPET` (Copper)
  - Percussion Fills: `SKELETON` (Click), `CREEPER` (Noise Burst)
- **Quantized Overdubbing**:
  - Live pad hits calculate target step: $\text{Step} = \lfloor \frac{\text{Time} - \text{Start}}{\text{Interval}} + 0.5 \rfloor \pmod{16}$.
  - Taps are recorded into active pattern while playing back in real time.
- **Export & Storage**:
  - Save patterns as JSON in `config/blockbard/patterns/`.
  - One-click export to standard MIDI (`.mid`) or Note Block Studio (`.nbs`) in `config/blockbard/midis/`.

---

## 3. Recommended Improvements Roadmap

### 3.1 In-World Organ Hologram & Status Overlay
- **Purpose**: Transform organ management from raw text into a live 3D visual augmented-reality interface.
- **Implementation**:
  - Extend `LevelRenderEvents.BEFORE_GIZMOS`.
  - Color-code every detected block in the organ:
    - **Green**: Assigned and verified in tune.
    - **Yellow**: Assigned, requires tuning clicks ($+N$ floating label).
    - **Blue**: Available spare block.
    - **Red**: Occluded / untunable.
    - **Purple**: Mob head ambient block.
  - Keybind toggle (<kbd>O</kbd>) and command `/bb overlay`.

### 3.2 Live Uniform Transpose Slider ($-12$ to $+12$ Semitones)
- **Purpose**: Prevent harmonic distortion when individual out-of-range notes are shifted by an octave.
- **Implementation**:
  - Add transpose slider / buttons in the transport bar of `MainScreen`.
  - Shifts all song notes uniformly before passing to `MidiToOrganMapper`.
  - Displays live coverage percentage for each semitone shift so the player can immediately pick the key that gives 100% organ coverage.

### 3.3 Dedicated GUI for Instrument Remapping
- **Purpose**: Provide a visual interface for `/bb remap`.
- **Implementation**:
  - Add "Remap" tab in `MainScreen`.
  - Lists instruments present in the current song with target replacement dropdowns or mute toggles.
  - Quick presets: "Mute Percussion", "All Brass to Flute", "Piano Only".

### 3.4 Continuous Line-of-Sight & Standing Spot Optimizer
- **Purpose**: Eliminate silent interaction drops caused by player movement or standing in spots with heavy internal occlusion.
- **Implementation**:
  - Re-evaluate line-of-sight cache in `PlayerController` on player movement $> 0.5$ blocks.
  - Enhance `centerOnOrgan()` to evaluate 3D candidate standing positions (including slabs / raised pedestals) to maximize visible faces.

### 3.5 NBS Custom Instrument Sound & Pitch Mapping
- **Purpose**: Enable proper playback of Note Block Studio files that use custom sound layers (instrument index $\ge 16$).
- **Implementation**:
  - Parse custom instrument metadata from NBS file headers.
  - Implement heuristic matching based on instrument name (e.g. matching "Electric Guitar" to `GUITAR` or `BIT`).
  - Allow manual user override mappings in configuration.

### 3.6 Live Performance Recording to MIDI/NBS
- **Purpose**: Allow musicians to record live jams from keyboard or USB MIDI controllers directly in-game.
- **Implementation**:
  - Arm recording via a "Record" transport button.
  - Timestamp incoming note requests into an event sequence buffer.
  - On stop, export standard MIDI file to `config/blockbard/midis/`.

### 3.7 Organ Blueprint & Ghost Block Guide
- **Purpose**: Simplify physical organ construction for players in survival mode.
- **Implementation**:
  - Render ghost blocks in concentric hemispheres around the player showing optimal foundation block placement.
  - Export layout as standard `.schem` / `.litematic` files for schematic placement mods.

---

## 4. Prioritization Matrix

| Feature | Target Subsystem | Complexity | Priority |
|---|---|---|---|
| In-World Organ Hologram Overlay | Client Rendering (`BEFORE_GIZMOS`) | Low | Immediate |
| Live Transpose Slider ($-12$ to $+12$) | Transport Controls / Mapper | Low | Immediate |
| Beat Maker Workstation (Sequencer & Pads) | GUI / Playback / Scheduler | High | Major Milestone |
| Instrument Remap GUI | GUI (`MainScreen`) | Medium | Near-term |
| NBS Custom Instrument Resolution | Playback (`NbsFileLoader`) | Medium | Near-term |
| Continuous Line-of-Sight Optimizer | Player Controller / Organ Map | Medium | Near-term |
| Live Performance Recording (.mid) | Input / Serialization | Medium | Future |
| Organ Blueprint / Ghost Builder | World Rendering / Schematics | High | Future |
