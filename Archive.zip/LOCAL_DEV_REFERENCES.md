# Local Developer References & Sibling Projects

This document tracks local sibling repositories located in `/Users/ethanchan/Documents/Applications/Minecraft Projects/` for quick reference during BlockBard development, reverse-engineering, and anticheat/protocol validation.

*(This file is git-ignored to prevent local machine paths from leaking into version control).*

---

## Sibling Directory Overview

| Project | Relative Path | Absolute Machine Path | Primary Architectural Purpose |
|---|---|---|---|
| **SongPlayer** | [`../SongPlayer/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/SongPlayer/) | `/Users/ethanchan/Documents/Applications/Minecraft Projects/SongPlayer` | Production Fabric note block player reference (stage movement, rotation gating, attack playback). |
| **Disc-Jockey** | [`../Disc-Jockey/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/Disc-Jockey/) | `/Users/ethanchan/Documents/Applications/Minecraft Projects/Disc-Jockey` | Fabric MIDI/NBS mod reference (packet budget rate-limiting per 100ms, note HUD overlays). |
| **mineflayer** | [`../mineflayer/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/mineflayer/) | `/Users/ethanchan/Documents/Applications/Minecraft Projects/mineflayer` | Autonomous bot client reference (visible face raycasting, digging model, anticheat reach validation). |
| **moddingdocs** | [`../moddingdocs/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/moddingdocs/) | `/Users/ethanchan/Documents/Applications/Minecraft Projects/moddingdocs` | Decompiled Minecraft & Fabric API sources (vanilla client/common sources, Fabric API source tree). |
| **NoteBlockLib** | [`../NoteBlockLib/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/NoteBlockLib/) | `/Users/ethanchan/Documents/Applications/Minecraft Projects/NoteBlockLib` | Note block helper utilities and pitch mapping algorithms. |
| **NoteBlockTool** | [`../NoteBlockTool/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/NoteBlockTool/) | `/Users/ethanchan/Documents/Applications/Minecraft Projects/NoteBlockTool` | Note block tooling and sound event helpers. |

---

## Detailed Directory Breakdowns & Key Source Files

### 1. SongPlayer (`../SongPlayer/`)
- **Key Source File**: [`SongHandler.java`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/SongPlayer/src/main/java/com/github/hhhzzzsss/songplayer/playing/SongHandler.java)
  - `doRotateIfNeeded(x, y, z)`: Demonstrates conditional gating (`if (Config.getConfig().rotate)`) for camera rotation and movement packet dispatching. When rotation is off, neither camera angles nor packets are modified.
  - `doSwingIfNeeded()`: Demonstrates optional arm swing animation (`Config.getConfig().swing`).
  - `attackBlock(BlockPos bp)`: Triggers note block sound via `mc.gameMode.startDestroyBlock(bp, Direction.UP)` without changing the block's `NOTE` tuning property.
- **Stage Construction**: [`Stage.java`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/SongPlayer/src/main/java/com/github/hhhzzzsss/songplayer/playing/Stage.java)
  - Layout generation for physical noteblock stages and spherical placement around the player.
- **File Converters**: [`conversion/`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/SongPlayer/src/main/java/com/github/hhhzzzsss/songplayer/conversion/)
  - `NBSConverter.java` & `MidiConverter.java`: Robust implementations for tick parsing, tempo changes, and multi-track note merging.

---

### 2. Disc-Jockey (`../Disc-Jockey/`)
- **Key Source File**: [`SongPlayer.java`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/Disc-Jockey/src/main/java/semmiedev/disc_jockey/SongPlayer.java)
  - **Packet Budgeting**: Implements a sliding 100ms packet budget (`last100MsReducePacketsAfter = 30`, `last100MsStopPacketsAfter = 45`) to throttle packet bursts and prevent server disconnects/kicks on Paper, Spigot, and Folia servers during dense chords.
  - `lastSwingSentAt` / `lastLookSentAt`: Throttles redundant arm swings and rotation updates to at most once per tick (50ms).
- **Note HUD Overlay**: [`BlocksOverlay.java`](file:///Users/ethanchan/Documents/Applications/Minecraft%20Projects/Disc-Jockey/src/main/java/semmiedev/disc_jockey/gui/hud/BlocksOverlay.java)
  - Visual display of active note blocks and live playback states.

---

### 3. mineflayer (`../mineflayer/`)
- **Key Source Files**:
  - `lib/plugins/digging.js`: Autonomous digging state machine, block interaction, and surface normal alignment.
  - `lib/plugins/raycast.js`: Line-of-sight ray tracing (`findBestVisibleFace`), geometric boundary surface detection, and distance filtering. Used to ensure interactions target valid visible faces and avoid back-face click rejections from anticheat plugins.

---

### 4. moddingdocs (`../moddingdocs/`)
- **Decompiled Source Dumps**:
  - `minecraftclientsource.xml`: Complete indexed decompiled sources for vanilla Minecraft client (UI, rendering, `LocalPlayer`, input handlers).
  - `minecraftcommonsource.xml`: Complete indexed decompiled sources for vanilla Minecraft common/server (`Level`, `BlockState`, `NoteBlock`, networking packets).
  - `fabricapi.xml` & `fabric-api/`: Full source tree of Fabric API modules (events, keybindings, lifecycle, networking).

---

### 5. NoteBlockTool (`../NoteBlockTool/`)
- **Key Source Files**:
  - `util/MinecraftOctaveClamp.java`: Enum handling note pitch correction policies (`NONE`, `INSTRUMENT_SHIFT`, `TRANSPOSE`, `CLAMP`).
  - `audio/SoundMap.java`: Wave synthesis and sound sample mapping for vanilla noteblock instruments.
  - `frames/edittabs/`: GUI editors for NBS custom instruments, note resampling, and metadata inspection.

---

### 6. NoteBlockLib (`../NoteBlockLib/`)
- **Key Source Files**:
  - `format/minecraft/MinecraftDefinitions.java`: Authoritative reference for `INSTRUMENT_SHIFTS` — natural acoustic shifts (e.g., Harp ↔ Bass/Bell, Flute ↔ Guitar, Xylophone ↔ Iron Xylophone) that keep musical pitch identical without transposing.
  - `format/minecraft/ShiftedMinecraftInstrument.java`: Models shifted noteblock instruments with octave offset counters.
  - `format/midi/MidiConverter.java`: Full MIDI track converter mapping GM patches to Minecraft noteblock instruments.
  - `format/nbs/`: Reference NBS v1–v5 parser, custom instruments, and tick-to-ms timing math.
