package kyrielie.blockbard.client

import kyrielie.blockbard.client.config.ConfigManager
import kyrielie.blockbard.client.gui.MainScreen
import kyrielie.blockbard.client.gui.PlaybackHud
import kyrielie.blockbard.client.input.KeyboardInputHandler
import kyrielie.blockbard.client.input.MidiInputHandler
import kyrielie.blockbard.client.playback.ClientPlayQueue
import kyrielie.blockbard.client.playback.PlaybackCoordinator
import kyrielie.blockbard.client.player.KickDiagnostics
import kyrielie.blockbard.client.player.MAX_ROTATION_DEGREES_PER_TICK
import kyrielie.blockbard.client.player.PlayerController
import kyrielie.blockbard.client.player.ROTATION_CONVERGENCE_THRESHOLD_DEGREES
import kyrielie.blockbard.client.player.SoundVerifier
import kyrielie.blockbard.organ.ArpeggioScheduler
import kyrielie.blockbard.organ.InstrumentShifter
import kyrielie.blockbard.client.organ.OrganScanner
import kyrielie.blockbard.organ.NoteBlockRegistry
import kyrielie.blockbard.util.DebugLog
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper
import net.minecraft.client.KeyMapping
import com.mojang.blaze3d.platform.InputConstants
import org.slf4j.LoggerFactory

object BlockBardClient : ClientModInitializer {

    const val MOD_ID = "blockbard"
    val logger = LoggerFactory.getLogger("BlockBard")

    private lateinit var openGuiKey: KeyMapping
    private lateinit var toggleHudKey: KeyMapping
    private lateinit var toggleOverlayKey: KeyMapping
    private var soundVerifierRegistered = false
    private var liveSyncTicker = 0

    override fun onInitializeClient() {
        logger.info("BlockBard initializing...")
        ConfigManager.load()
        val cfg = ConfigManager.config
        logger.info(
            "Config loaded: scanRadius=${cfg.scanRadius}, shiftMode=${cfg.shiftMode}, " +
            "arpeggioStaleTimeoutMs=${cfg.arpeggioStaleTimeoutMs}, " +
            "debugLogging=${cfg.debugLogging}, maxNotesPerTick=${cfg.maxNotesPerTick}, " +
            "loopMode=${cfg.loopMode}"
        )

        // Tier 1: apply debug logging flag to DebugLog before anything else logs
        DebugLog.enabled = cfg.debugLogging

        OrganScanner.scanRadius = cfg.scanRadius
        OrganScanner.sphericalScan = cfg.sphericalScan
        InstrumentShifter.mode = cfg.shiftModeEnum()
        InstrumentShifter.maxOctaveShift = cfg.maxOctaveShift
        ArpeggioScheduler.staleTimeoutMs = cfg.arpeggioStaleTimeoutMs
        ArpeggioScheduler.rotationInProgressTimeoutMs = cfg.rotationInProgressTimeoutMs
        // Tier 2: max notes per tick
        ArpeggioScheduler.maxNotesPerTick = cfg.maxNotesPerTick.coerceIn(1, 64)
        MAX_ROTATION_DEGREES_PER_TICK = cfg.maxRotationDegreesPerTick
        ROTATION_CONVERGENCE_THRESHOLD_DEGREES = cfg.rotationConvergenceThresholdDegrees

        ArpeggioScheduler.interactDelegate = { pos, request ->
            logger.debug("interactDelegate: -> $pos (MIDI ${request.midiNote})")
            PlayerController.playNoteAt(pos, request)
        }
        ArpeggioScheduler.dynamicRetuningEnabled = cfg.dynamicRetuning
        ClientPlayQueue.applyConfig(cfg)
        // Playback-thread song-end callbacks; the decision itself runs from the END_CLIENT_TICK below.
        PlaybackCoordinator.install()
        ArpeggioScheduler.dynamicRetuneDelegate = { pos, request ->
            logger.debug("dynamicRetuneDelegate: -> $pos (MIDI ${request.midiNote})")
            PlayerController.retuneAndPlayNoteAt(pos, request)
        }
        ArpeggioScheduler.rotationConvergedDelegate = { pos ->
            PlayerController.rotationConverged(pos)
        }
        ArpeggioScheduler.onNoteDispatched = { midiNote, instrument ->
            kyrielie.blockbard.client.gui.VisualizerState.trigger(midiNote, instrument)
        }

        val blockbardCategory = KeyMapping.Category.register(net.minecraft.resources.Identifier.fromNamespaceAndPath("blockbard", "general"))
        openGuiKey = KeyMappingHelper.registerKeyMapping(
            KeyMapping("key.blockbard.open_gui", InputConstants.KEY_B, blockbardCategory)
        )
        toggleHudKey = KeyMappingHelper.registerKeyMapping(
            KeyMapping("key.blockbard.toggle_hud", InputConstants.KEY_H, blockbardCategory)
        )
        toggleOverlayKey = KeyMappingHelper.registerKeyMapping(
            KeyMapping("key.blockbard.toggle_overlay", InputConstants.KEY_O, blockbardCategory)
        )
        logger.info("Keybindings registered: B=open GUI, H=toggle HUD, O=toggle hologram overlay")

        KeyboardInputHandler.register()
        PlaybackHud.isVisible = cfg.hudEnabled
        PlaybackHud.register()
        KickDiagnostics.register()
        kyrielie.blockbard.client.render.ManualTuningHighlighter.register()
        kyrielie.blockbard.client.render.OrganOverlayRenderer.register()
        kyrielie.blockbard.client.render.OrganBlueprintBuilder.register()
        kyrielie.blockbard.client.gui.MaterialsShoppingOverlay.register()
        kyrielie.blockbard.client.command.BlockBardCommands.register()

        // Prime rotation in START_CLIENT_TICK -- fires before LocalPlayer.tick() calls
        // sendPosition(), so each tick's eased rotation step is included in that tick's
        // movement packet. Drives playback rotation only. Tuning primes its own rotation
        // through MainScreen's primeRotation lambda (isTuning = true); both write the single
        // PlayerController.primedRotation field, so while a tuner is active it owns rotation
        // and this handler stays out of the way.
        ClientTickEvents.START_CLIENT_TICK.register { _ ->
            if (MainScreen.activeTuner?.isActive == true) return@register
            ArpeggioScheduler.peekNextPos()?.let { PlayerController.primeRotation(it) }
        }

        ClientTickEvents.END_CLIENT_TICK.register { mc ->
            // SoundVerifier needs mc.soundManager, which is not available during
            // onInitializeClient() -- deferred to first tick via a one-shot flag.
            if (!soundVerifierRegistered) {
                mc.soundManager.addListener(SoundVerifier)
                soundVerifierRegistered = true
                logger.info("SoundVerifier registered as a SoundEventListener")
            }

            liveSyncTicker++
            if (liveSyncTicker >= 20) {
                liveSyncTicker = 0
                mc.level?.let { NoteBlockRegistry.refreshLiveNoteValues(it) }
            }
            kyrielie.blockbard.client.render.ManualTuningHighlighter.updateWorldState()

            while (openGuiKey.consumeClick()) {
                logger.info("B pressed -- opening MainScreen")
                if (mc.gui.screen() == null) mc.gui.setScreen(MainScreen())
            }
            while (toggleHudKey.consumeClick()) {
                PlaybackHud.isVisible = !PlaybackHud.isVisible
                ConfigManager.config.hudEnabled = PlaybackHud.isVisible
                ConfigManager.save()
                val status = if (PlaybackHud.isVisible) "enabled" else "disabled"
                mc.player?.sendSystemMessage(net.minecraft.network.chat.Component.literal("§b[BlockBard] §fPlayback HUD $status"))
                logger.info("H pressed -- HUD visible=${PlaybackHud.isVisible}")
            }
            while (toggleOverlayKey.consumeClick()) {
                val on = kyrielie.blockbard.client.render.OrganOverlayRenderer.toggle()
                val status = if (on) "§aenabled" else "§cdisabled"
                mc.player?.sendSystemMessage(net.minecraft.network.chat.Component.literal("§b[BlockBard] §fOrgan hologram overlay $status"))
                logger.info("O pressed -- Organ overlay visible=$on")
            }
            MidiInputHandler.tickRetry()
            MainScreen.onClientTick(mc)
            // Song end and auto-advance, with or without the GUI open.
            PlaybackCoordinator.tick()
            ArpeggioScheduler.onTick()
        }

        MidiInputHandler.autoConnect()
        logger.info("BlockBard initialized.")
    }
}
